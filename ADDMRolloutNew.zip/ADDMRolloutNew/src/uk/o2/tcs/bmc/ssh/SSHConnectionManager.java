/**
 * 
 */
package uk.o2.tcs.bmc.ssh;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PipedInputStream;
import java.io.PipedOutputStream;
import java.util.Properties;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;

/**
 * @author Murugavel Ramachandran
 *
 */
public class SSHConnectionManager {
	
	private String username;
	private String password;
	private String hostname;
	
	private Session session;
	private ChannelExec channel;
	
	public SSHConnectionManager(String hostname, String username, String password) {
		// TODO Auto-generated constructor stub
		this.username = username;
		this.password = password;
		this.hostname = hostname;
	}
	
	private Session getSession(){
		if(session == null || !session.isConnected()){
	        session = connect(hostname,username,password);
	    }
	    return session;
	}
	
	private Session connect(String hostname, String username, String password){

	    JSch jSch = new JSch();

	    try {
	    	session = jSch.getSession(username, hostname, 22);
	        session.setConfig("PreferredAuthentications", "publickey,keyboard-interactive,password");
	        session.setPassword(password);
	        Properties config = new Properties(); 
	        config.put("StrictHostKeyChecking", "no");
	        session.setConfig(config);
	        session.connect(60000);
	        System.out.println("Connected!");
	    }catch(Exception e){
	        System.out.println("An error occurred while connecting to "+hostname+": "+e);
	    }

	    return session;

	}
	
	public void close(){
	    session.disconnect();
	    System.out.println("Disconnected session");
	}
	
	public static boolean checkUserConnection(String remoteHostUserName, String remoteHostName, String remoteHostpassword) {
	    
	    boolean flag;
	    try{
	    	JSch js = new JSch();
	    	Session s = js.getSession(remoteHostUserName, remoteHostName, 22);
	    	s.setConfig("PreferredAuthentications", "publickey,keyboard-interactive,password");
		    s.setPassword(remoteHostpassword);
		    Properties config = new Properties();
		    config.put("StrictHostKeyChecking", "no");
		    s.setConfig(config);
		    s.connect();
		    flag = true;
		    s.disconnect();  		    	
	    }catch(Exception e){
	    	flag = false;
	    }
	    return flag;
	}

	 public boolean remoteCopy(String scriptFile) {
		 try
	     {
			 Channel c = getSession().openChannel("sftp");
			 ChannelSftp ce = (ChannelSftp) c;
			 ce.connect();
			 ce.put(scriptFile,"/tmp/"+scriptFile);
			 ce.disconnect();
			 return true;
	     }catch(Exception ex){
	    	 ex.printStackTrace();
	    	 return false;
	     }
	}
	
	public String removePassEntry(String str, String pass)
	{
		str = str.replaceAll(pass, "");
		return str;
	}
	
	public String executeSudoCommand1(String sudoPath, String password, String command){
		
		StringBuffer stringBuffer = new StringBuffer();
		boolean flag=false;

		try{
			Channel channel = getSession().openChannel("exec");
			((ChannelExec)channel).setCommand(sudoPath+" -S -p '' "+command);
			((ChannelExec) channel).setPty(true);
			OutputStream out=channel.getOutputStream();
			((ChannelExec)channel).setErrStream(System.err);
			
			channel.connect(1000);
			
			out.write((password+"\n").getBytes());
			out.flush();
			
			
			InputStream in = channel.getInputStream();
			
			byte[] buffer = new byte[1024];
			int count = 1;

			while (channel.getExitStatus() == -1) {
				while (in.available() > 0) {
					int i = in.read(buffer, 0, 1024);
					if (i < 0) {
						System.out.println("Breaking");
						break;
					}
					String s = new String(buffer, 0, i);
					stringBuffer.append(s);
					System.out.println("buffer="+s);
				}
				if(channel.isClosed()){
					System.out.println("Channel is closed");
					break;
				}

				if(count > 1000){
					   System.out.println("Count BREAK ="+count);

					   flag=true;
		        	   break;
			    }
		        //System.out.println(count);
		        count++;
			}
			in.close();
			channel.disconnect();
			System.out.println("Done");
		}catch(IOException ex){
			ex.printStackTrace();
		}catch(JSchException ex){
			ex.printStackTrace();
		}
		
		if(flag){
			   //String muru = executeSudoCommand(sudoPath, password, command);
			   //System.out.println("Count BREAK ="+muru);			
		}

		
		return stringBuffer.toString();

	}
	
	public String executeExecSudoCommand(String sudoPath, String password, String command){
		
		StringBuffer stringBuffer = new StringBuffer();
		System.out.println(sudoPath+" -S -p '' "+command);
		
		try {
		    Channel channel = getSession().openChannel("exec");
		    ((ChannelExec)channel).setCommand(sudoPath+" -S -p '' "+command);
		    channel.connect();

		    try {
		        InputStream in = channel.getInputStream();
		        OutputStream out = channel.getOutputStream();

		        out.write((password + System.getProperty("line.separator")).getBytes());

		        BufferedReader reader = new BufferedReader(new InputStreamReader(in));
		        String line = null;
		        while (null != (line = reader.readLine())) {
		            System.out.println(line);
		        }
		    } finally {
		        channel.disconnect();
		    }
		}catch(IOException ex){
			ex.printStackTrace();
		}catch(JSchException ex){
			ex.printStackTrace();
		}
		

		
		return stringBuffer.toString();
		
	}
	
	public String executeShellSudoCommand(String sudoPath, String password, String command){
		
		StringBuffer stringBuffer = new StringBuffer();
		
		try{
			Channel channel = getSession().openChannel("shell");
			
			// create the IO streams to send input to remote session.
			PipedOutputStream commandIO = new PipedOutputStream();
			InputStream sessionInput = new PipedInputStream(commandIO);
			// this set's the InputStream the remote server will read from.
			channel.setInputStream(sessionInput);
			
			// this will have the STDOUT from server.
			InputStream sessionOutput = channel.getInputStream();
			
			// this will have the STDERR from server
			InputStream sessionError = channel.getExtInputStream();
			
			channel.connect();
			

			command = "sudo su - root\n";
			commandIO.write(command.getBytes());
			commandIO.flush();
			
			// Read input until we get the 'Password:' prompt
			byte[] tmp = new byte[1024];
			String stdOut = "";
			String stdErr = "";
			
			int i;
			
			while (channel.getExitStatus() == -1) {
				if (sessionError.available() > 0) {
	                i = sessionError.read(tmp, 0, tmp.length);
	                if (i < 0) {
	                    System.err.println("input stream closed earlier than expected");
	                    System.exit(1);
	                }
	                stdErr += new String(tmp, 0, i);
	            }

	            if (sessionOutput.available() > 0) {
	                i = sessionOutput.read(tmp, 0, tmp.length);
	                if (i < 0) {
	                    System.err.println("input stream closed earlier than expected");
	                    System.exit(1);
	                }
	                stdOut += new String(tmp, 0, i);
	            }

	            if (stdOut.contains("assword")) {
	                break;
	            }

	            //try{Thread.sleep(1000);}catch(Exception ee){}
	        }
			
			command = password + "\n";
			commandIO.write(command.getBytes());
			commandIO.flush();
			
			// The rest of the commands are just for terminal
			
			commandIO.write("whoami\n".getBytes());
			commandIO.flush();
			
			// logout from user2
			commandIO.write("exit\n".getBytes());
			
			// read and print output.
			if ((i = sessionOutput.read(tmp, 0, tmp.length)) != -1) {
				System.out.println("buffer="+new String(tmp, 0, i));

			}
			
			// cleanup.
			
			commandIO.close();
			sessionInput.close();

			channel.disconnect();
			System.out.println("Done");
		}catch(IOException ex){
			ex.printStackTrace();
		}catch(JSchException ex){
			ex.printStackTrace();
		}
		
		return stringBuffer.toString();

	}

}
