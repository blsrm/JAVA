/**
 * 
 */
package uk.o2.tcs.bmc.addm;

/**
 * @author Murugavel Ramachandran
 *
 */
public class ADDMWrapperMain {

	public static String batch = "";
    public static String mode = "";
    public static String file = "";
    
	public static void main(String[] args) {
		
		// ADDM_Wrapper.java [-batch T4] -mode scan/update -file excel_filename 
	    for (int i=0; i < args.length; i++) {
	         switch (args[i].charAt(0)) {
	         case '-':
	             if (args[i].charAt(1) == '-') {
	                 int len = 0;
	                 String argstring = args[i].toString();
	                 len = argstring.length();
	                 if(argstring.substring(2, len).toString().equalsIgnoreCase("batch")){ batch = args[i+1]; } 
	                 else if(argstring.substring(2, len).toString().equalsIgnoreCase("mode")){ mode = args[i+1]; }
	                 else if(argstring.substring(2, len).toString().equalsIgnoreCase("file")){ file = args[i+1]; }
	                 i= i+1;
	             } else {
	            	 int len = 0;
	                 String argstring = args[i].toString();
	                 len = argstring.length();
	                 if(argstring.substring(1, len).toString().equalsIgnoreCase("batch")){ batch = args[i+1]; } 
	                 else if(argstring.substring(1, len).toString().equalsIgnoreCase("mode")){ mode = args[i+1]; }
	                 else if(argstring.substring(1, len).toString().equalsIgnoreCase("file")){ file = args[i+1]; }
	                 i= i+1;
	             }           
	             break;         
	         default:            
	         	break;         
	         }     
		}
		
	    if(mode.equalsIgnoreCase("") || file.equalsIgnoreCase("") || args.length < 4){
	    	System.out.println("\nADDM Rollout Wrapper Tool to connect Linux, Solaris and HP-UX");
	    	System.out.println("\n\tUsage: ADDM_Wrapper.java [-batch T4] -mode [scan/update] -file excelfilename");
	    } else {
	    	ADDMWrapper addm = new ADDMWrapper(batch, mode, file);
	    	addm.startADDMWrapper();
	    }

	}

}
