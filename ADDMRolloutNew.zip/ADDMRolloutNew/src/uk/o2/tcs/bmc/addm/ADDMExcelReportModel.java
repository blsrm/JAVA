/**
 * 
 */
package uk.o2.tcs.bmc.addm;

/**
 * @author Murugavel Ramachandran
 *
 */
public class ADDMExcelReportModel {

	public String hostname;
	public String username;
	public String password;
	public String osname;
	public String batch;
	public String ipaddress;
	public String nslookup;
	public String uidstatus;
	public String gidstatus;
	public String filestatus;
	public String sshkey;
	public String sshpermission;
	public String sudostatus;
	public String scriptlog;
	public String overallstatus;
	public String homedir;
	public String securelogstatus;
	public String sshExceptionStatus;
	
	public String getHostname() {
		return hostname;
	}
	public void setHostname(String hostname) {
		this.hostname = hostname;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getOsname() {
		return osname;
	}
	public void setOsname(String osname) {
		this.osname = osname;
	}
	public String getBatch() {
		return batch;
	}
	public void setBatch(String batch) {
		this.batch = batch;
	}
	public String getIpaddress() {
		return ipaddress;
	}
	public void setIpaddress(String ipaddress) {
		this.ipaddress = ipaddress;
	}
	public String getUidstatus() {
		return uidstatus;
	}
	public void setUidstatus(String uidstatus) {
		this.uidstatus = uidstatus;
	}
	public String getGidstatus() {
		return gidstatus;
	}
	public void setGidstatus(String gidstatus) {
		this.gidstatus = gidstatus;
	}
	public String getFilestatus() {
		return filestatus;
	}
	public void setFilestatus(String filestatus) {
		this.filestatus = filestatus;
	}
	public String getSshkey() {
		return sshkey;
	}
	public void setSshkey(String sshkey) {
		this.sshkey = sshkey;
	}
	public String getSshpermission() {
		return sshpermission;
	}
	public void setSshpermission(String sshpermission) {
		this.sshpermission = sshpermission;
	}
	public String getSudostatus() {
		return sudostatus;
	}
	public void setSudostatus(String sudostatus) {
		this.sudostatus = sudostatus;
	}
	public String getOverallstatus() {
		return overallstatus;
	}
	public void setOverallstatus(String overallstatus) {
		this.overallstatus = overallstatus;
	}
	public String getScriptlog() {
		return scriptlog;
	}
	public void setScriptlog(String scriptlog) {
		this.scriptlog = scriptlog;
	}
	public String getHomedir() {
		return homedir;
	}
	public void setHomedir(String homedir) {
		this.homedir = homedir;
	}
	public String getNslookup() {
		return nslookup;
	}
	public void setNslookup(String nslookup) {
		this.nslookup = nslookup;
	}
	public String getSecurelogstatus() {
		return securelogstatus;
	}
	public void setSecurelogstatus(String securelogstatus) {
		this.securelogstatus = securelogstatus;
	}

	public String getSshExceptionStatus() {
		return sshExceptionStatus;
	}
	public void setSshExceptionStatus(String sshExceptionStatus) {
		this.sshExceptionStatus = sshExceptionStatus;
	}
	
	

}

