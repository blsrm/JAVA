/**
 * 
 */
package uk.o2.tcs.bmc.addm;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 * @author prabakh1
 *
 */
public class Common {

	void breakLine(){
		 try{
			 BufferedReader bufferRead = new BufferedReader(new InputStreamReader(System.in));
			 String s = bufferRead.readLine();
			 System.out.println(s);
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}		
	}
	 
	public String clean(String str){
		str = str.trim();
		return str;
	}
	
	public void writeOutput(String tab, String str){
		if(tab.equalsIgnoreCase("")) {
			System.out.println(str);
		} else {
			System.out.println("\t"+str);
		}
		
	}
	
}
