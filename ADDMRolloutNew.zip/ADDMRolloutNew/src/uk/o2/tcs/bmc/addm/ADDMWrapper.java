/**
 * 
 */
package uk.o2.tcs.bmc.addm;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

import uk.o2.tcs.bmc.ssh.SSHConnectionManager;

import jxl.Sheet;
import jxl.Workbook;
import jxl.WorkbookSettings;
import jxl.read.biff.BiffException;

/**
 * @author Murugavel Ramachandran
 *
 */
public class ADDMWrapper {
	
	public String batch = "";
    public String mode = "";
    public String file = "";
    
	ArrayList<String> excel_input_arr = new ArrayList<String>();
	ArrayList<ADDMExcelReportModel> addm_model_arr = new ArrayList<ADDMExcelReportModel>();
	
	//Object Creation
	Common com = new Common();
	
	public ADDMWrapper(String batch, String mode, String file){
		this.batch = batch;
		this.mode = mode;
		this.file = file;
	}
	
	public void startADDMWrapper(){
		System.out.println("Inside start");
		collectADDMHosts(file, batch);
		processingADDMData();
	}
	
	
	public void processingADDMData() {
		
		Iterator<String> itr = excel_input_arr.iterator();
		int count = 1;
		
		while(itr.hasNext()){
			
			//Assign Variables
			String hostname = "";
			String username = "";
			String password = "";
			boolean userFlag = false;
			
			String line = itr.next();
			String data_arr[] = line.split("\\|");
			
			hostname = data_arr[0];
			
			com.writeOutput("", "\nProcessing ADDM Rollout task for hostname '"+hostname+"' - "+batch+"' - "+count+" of "+excel_input_arr.size());
			
			//Checking User and password authentication 
			String userPassList = data_arr[2];
			
			if(! userPassList.equalsIgnoreCase("")){
				String userPassArr[] = userPassList.split(",");
				for(int i=0; i<userPassArr.length; i++){
					String userPair[] = userPassArr[i].toString().split(":");
					userFlag = SSHConnectionManager.checkUserConnection(userPair[0], data_arr[0], userPair[1]);
					username = userPair[0];
					password = userPair[1];
					com.writeOutput("tab", "Trying to connect "+username+":"+password+ "@"+hostname+" .... "+ userFlag);
					if(userFlag){
						break;
					}
				}
			}else {
				System.out.println("\tUpdate password entry in excel for hostname="+hostname);
			}
			
			if(userFlag){
				scanOrUpdateHostForADDM(hostname, username, password, data_arr);
			}else {
				ADDMExcelReportModel addmModelObj = new ADDMExcelReportModel();
				addmModelObj.setHostname(hostname);
				addmModelObj.setUsername("Authentication issues for provided users to access server.");
				addmModelObj.setBatch(batch);
				addm_model_arr.add(addmModelObj);
				
			}

			count++;
		}
		
		//Excel Report Generation
		//ADDMReportExcel are = new ADDMReportExcel();
		//are.processADDMRolloutReport(addm_model_arr, batch);

		
	}


	public void scanOrUpdateHostForADDM(String hostname, String username, String password, String [] data_arr){
	
		ADDMExcelReportModel addmModelObj = new ADDMExcelReportModel();
		SSHConnectionManager sshObj = new SSHConnectionManager(hostname, username, password);
	
		String osName = com.clean(sshObj.executeShellSudoCommand("/usr/local/bin/sudo", password, "uname -s"));
		
		com.writeOutput("tab", osName);

	
	
	}
	
	public void collectADDMHosts(String fileName, String batch){
		
		try {

			WorkbookSettings ws = new WorkbookSettings();
			ws.setEncoding("UTF-8");
			
			//Create a workbook object from the file at specified location. 
			//Change the path of the file as per the location on your computer. 
			Workbook wrk1 =  Workbook.getWorkbook(new File(fileName), ws);
			
			//Obtain the reference to the first sheet in the workbook
			Sheet sheet1 = wrk1.getSheet(0);
			
            int columns = sheet1.getColumns();
            int rows = sheet1.getRows();
            String data;

            for (int row = 0; row < rows; row++) {
            	String line = "";
                for (int col = 0; col < columns; col++) {
                	data = sheet1.getCell(col, row).getContents();
                    line = line + data + "|";
                }
                line = line + "END"; // Just for dummy
                
                String line_temp = line;
                line_temp = line_temp.replaceAll("\\|", "");
                line_temp = line_temp.replaceAll("END", "");
                
                 if( ! line.contains("Host Name") && 
               		! line.contains("IP Endpint") && 
               		! line_temp.equalsIgnoreCase("")
                ){
                	if( batch.equalsIgnoreCase("") ){
                		excel_input_arr.add(line);
                		//System.out.println("MURU"+line);
                		//com.breakLine();
                	} else {
                		if(line.contains("|"+batch+"|")) {
                			excel_input_arr.add(line);
                		}
                	}
                }
 
            }
            
		} catch (BiffException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	

}
