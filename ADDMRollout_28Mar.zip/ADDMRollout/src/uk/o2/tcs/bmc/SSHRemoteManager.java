/**
 * 
 */
package uk.o2.tcs.bmc;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.SocketTimeoutException;
import java.util.Properties;
import java.util.concurrent.TimeoutException;

import uk.o2.tcs.bmc.model.ADDMDataModel;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.ChannelShell;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;

/**
 * @author Murugavel Ramachandran
 *
 */
// https://gist.github.com/kdelfour/5f1fde64c3d23daea704

public class SSHRemoteManager {

	private String username;
	private String password;
	private String hostname;
	
	private Session session;
	private ChannelExec channel;
	
	public SSHRemoteManager(String hostname, String username, String password) {
		// TODO Auto-generated constructor stub
		this.username = username;
		this.password = password;
		this.hostname = hostname;
	}
	
	private Session getSession(){
		if(session == null || !session.isConnected()){
	        session = connect(hostname,username,password);
	    }
	    return session;
	}

	private Channel getChannel(){
	    if(channel == null || !channel.isConnected()){
	        try{
	            channel = (ChannelExec)getSession().openChannel("exec");
	            channel.connect();
	        }catch(Exception e){
	            System.out.println("Error while opening channel: "+ e);
	        }
	    }
	    return channel;
	}
	
	private Session connect(String hostname, String username, String password){

	    JSch jSch = new JSch();

	    try {
	    	session = jSch.getSession(username, hostname, 22);
	        session.setConfig("PreferredAuthentications", "publickey,keyboard-interactive,password");
	        session.setPassword(password);
	        Properties config = new Properties(); 
	        config.put("StrictHostKeyChecking", "no");
	        session.setConfig(config);
	        session.connect(60000);
	        System.out.println("Connected!");
	    }catch(Exception e){
	        System.out.println("An error occurred while connecting to "+hostname+": "+e);
	    }

	    return session;

	}

	public String executeCommand(String command)
	  {
	     StringBuilder outputBuffer = new StringBuilder();
	     //System.out.println(command);
	     try
	     {
	        Channel channel = getSession().openChannel("exec");
	        ((ChannelExec)channel).setCommand(command);
	        InputStream commandOutput = channel.getInputStream();
	        ((ChannelExec)channel).setErrStream(System.err);
	        
	        channel.connect();
	        
	        int count = 1;
	        int readByte = commandOutput.read();
	        while(readByte != 0xffffffff && commandOutput.available()>0)
	        {
	           outputBuffer.append((char)readByte);
	           readByte = commandOutput.read();
	           if(count>1000){
	        	   break;
		       }
	           count++;
	        }

	        channel.disconnect();
	     }
	     catch(IOException ioX)
	     {
	        return ioX.getMessage();
	     }
	     catch(JSchException jschX)
	     {
	        return jschX.getMessage();
	     }

	     return outputBuffer.toString();
	  }
	
	public String executeShellCommand(String command)
	  {
	     StringBuilder outputBuffer = new StringBuilder();
	     System.out.println(command);
	     try
	     {
	        Channel channel = getSession().openChannel("exec");
	        ((ChannelExec)channel).setCommand(command);
	        ((ChannelExec) channel).setPty(true);
	        
	        ((ChannelExec)channel).setErrStream(System.err);
	        
	        channel.connect(1000);
	        InputStream commandOutput = channel.getInputStream();
	        int count = 1;
	        int readByte = commandOutput.read();
	        while(readByte != 0xffffffff && commandOutput.available()>0)
	        {
	           outputBuffer.append((char)readByte);
	           readByte = commandOutput.read();
	           if(count>1000){
	        	   break;
		       }
	           count++;
	        }

	        channel.disconnect();
	     }
	     catch(IOException ioX)
	     {
	        return ioX.getMessage();
	     }
	     catch(JSchException jschX)
	     {
	        return jschX.getMessage();
	     }

	     return outputBuffer.toString();
	  }

	public String executeSudoCommand(ADDMDataModel addmModelObj, String sudoPath, String password, String command)
	{
	     StringBuilder outputBuffer = new StringBuilder();
	     System.out.println("sudoPath="+sudoPath);

	     try
	     {
	        Channel channel = getSession().openChannel("exec");
	        
	        System.out.println(sudoPath+" -S -p '' "+command);
	        
	        ((ChannelExec)channel).setCommand(sudoPath+" -S -p '' "+command);
	        ((ChannelExec) channel).setPty(true);
	        
	        OutputStream out=channel.getOutputStream();
	        ((ChannelExec)channel).setErrStream(System.err);
	        
	        channel.connect();
	        
	        out.write((password+"\n").getBytes());
	        out.flush();
	        
	        InputStream commandOutput = channel.getInputStream();
	        
	        int count = 1;
	        int readByte = commandOutput.read();
	        while(readByte != 0xffffffff)
	        {
	        	
	           outputBuffer.append((char)readByte);
	           //System.out.println(count + "="+ (char)readByte);
	           try{
	        	   readByte = commandOutput.read();
	           }catch(SocketTimeoutException ex){
	        	   ex.printStackTrace();
	           }catch(IOException ex){
	        	   ex.printStackTrace();
	           }
	           
	           if(count > 1000){
	        	   break;
		       }
	           count++;
	        }
	        channel.disconnect();
	     }
	     catch(IOException ioX)
	     {
	        return ioX.getMessage();
	     }
	     catch(JSchException jschX)
	     {
	        return jschX.getMessage();
	     }
	     
	     return removePassEntry(outputBuffer.toString(), password);
	}
	
	public String executeSudoCommandNOK(String sudoPath, String password, String command)
	{
	     StringBuilder outputBuffer = new StringBuilder();
	     System.out.println("sudoPath="+sudoPath);
	     String output = "";
	     try
	     {
	        Channel channel = getSession().openChannel("exec");
	        
	        System.out.println(sudoPath+" -S -p '' "+command);
	        
	        ((ChannelExec)channel).setCommand(sudoPath+" -S -p '' "+command);
	        ((ChannelExec) channel).setPty(true);
	        InputStream commandOutput = channel.getInputStream();
	        OutputStream out=channel.getOutputStream();
	        ((ChannelExec)channel).setErrStream(System.err);
	        
	        channel.connect(1000);
	        //channel.run();
	        
	        out.write((password+"\n").getBytes());
	        out.flush();
	        
	        //Sorry, try again.
	        //sudo: pam_authenticate: Conversation failure
	        
	        int count = 1;
	        int readByte = commandOutput.read();
	        while(readByte != 0xffffffff)
	        {
	        	
	           outputBuffer.append((char)readByte);
	           try{
	        	   readByte = commandOutput.read();
	           }catch(SocketTimeoutException ex){
	        	   ex.printStackTrace();
	           }catch(IOException ex){
	        	   ex.printStackTrace();
	           }
	           
	           System.out.println((char)readByte + " = commandOutput.available()="+commandOutput.available());
	           if(count > 1000 || readByte<0){
	        	   break;
		       }
	           //System.out.println(count);
	           count++;
	        }
	        //System.out.println("Exit of While loop");
	        channel.disconnect();
	     }
	     catch(IOException ioX)
	     {
	        return ioX.getMessage();
	     }
	     catch(JSchException jschX)
	     {
	        return jschX.getMessage();
	     }
	     
	     return removePassEntry(outputBuffer.toString(), password);
	}
	
	public String executeSudoCommand1(ADDMDataModel addmModelObj, String sudoPath, String password, String command){
		
		StringBuffer stringBuffer = new StringBuffer();
		boolean flag=false;
		addmModelObj.setSshExceptionStatus("false");
		try{
			Channel channel = getSession().openChannel("exec");
			((ChannelExec)channel).setCommand(sudoPath+" -S -p '' "+command);
			((ChannelExec) channel).setPty(true);
			OutputStream out=channel.getOutputStream();
			((ChannelExec)channel).setErrStream(System.err);
			
			channel.connect(1000);
			
			out.write((password+"\n").getBytes());
			out.flush();
			
			
			InputStream in = channel.getInputStream();
			
			byte[] buffer = new byte[1024];
			int count = 1;

			while (channel.getExitStatus() == -1) {
				while (in.available() > 0) {
					int i = in.read(buffer, 0, 1024);
					if (i < 0) {
						System.out.println("Breaking");
						break;
					}
					String s = new String(buffer, 0, i);
					stringBuffer.append(s);
					System.out.println("buffer="+s);
				}
				if(channel.isClosed()){
					System.out.println("Channel is closed");
					break;
				}

				if(count > 1000){
					   System.out.println("Count BREAK ="+count);
					   addmModelObj.setSshExceptionStatus("true");
					   flag=true;
		        	   break;
			    }
		        //System.out.println(count);
		        count++;
			}
			in.close();
			channel.disconnect();
			System.out.println("Done");
		}catch(IOException ex){
			ex.printStackTrace();
		}catch(JSchException ex){
			ex.printStackTrace();
		}
		
		if(flag){
			   //String muru = executeSudoCommand(sudoPath, password, command);
			   //System.out.println("Count BREAK ="+muru);			
		}

		
		return stringBuffer.toString();

	}
	
	public String executeShellCommandNew(String command){
		
		StringBuffer stringBuffer = new StringBuffer();
		
		try{
			Channel channel = getSession().openChannel("exec");
			((ChannelExec)channel).setCommand(command);
			((ChannelExec)channel).setErrStream(System.err);
			channel.connect(1000);
			
			InputStream in = channel.getInputStream();
			
			byte[] buffer = new byte[1024];
			
			while (channel.getExitStatus() == -1) {
				while (in.available() > 0) {
					int i = in.read(buffer, 0, 1024);
					if (i < 0) {
						System.out.println("Breaking");
						break;
					}
					String s = new String(buffer, 0, i);
					stringBuffer.append(s);
					System.out.println("buffer="+s);
				}
				if(channel.isClosed()){
					System.out.println("Channel is closed");
					break;
				}
			}
			in.close();
			channel.disconnect();
			System.out.println("Done");
		}catch(IOException ex){
			ex.printStackTrace();
		}catch(JSchException ex){
			ex.printStackTrace();
		}
		
		return stringBuffer.toString();

	}
	
	public String executeSudoCommand1_OK(String sudoPath, String password, String command){
		
		StringBuffer stringBuffer = new StringBuffer();
		
		try{
			Channel channel = getSession().openChannel("exec");
			((ChannelExec)channel).setCommand(sudoPath+" -S -p '' "+command);
			OutputStream out=channel.getOutputStream();
			((ChannelExec)channel).setErrStream(System.err);
			
			channel.connect(1000);
			
			out.write((password+"\n").getBytes());
			out.flush();
			
			InputStream in = channel.getInputStream();
			
			byte[] buffer = new byte[1024];
			
			while (channel.getExitStatus() == -1) {
				while (in.available() > 0) {
					int i = in.read(buffer, 0, 1024);
					if (i < 0) {
						System.out.println("Breaking");
						break;
					}
					String s = new String(buffer, 0, i);
					stringBuffer.append(s);
					System.out.println("buffer="+s);
				}
				if(channel.isClosed()){
					System.out.println("Channel is closed");
					break;
				}
			}
			in.close();
			channel.disconnect();
			System.out.println("Done");
		}catch(IOException ex){
			ex.printStackTrace();
		}catch(JSchException ex){
			ex.printStackTrace();
		}
		
		return stringBuffer.toString();

	}
	
	public void close(){
	    session.disconnect();
	    System.out.println("Disconnected session");
	}
	
	
	public static boolean checkUserConnection(String remoteHostUserName, String remoteHostName, String remoteHostpassword) {
		 
	 	System.out.println(remoteHostName);
	 	System.out.println(remoteHostUserName);
	 	System.out.println(remoteHostpassword);
	    
	    boolean flag;
	    try{
	    	JSch js = new JSch();
	    	Session s = js.getSession(remoteHostUserName, remoteHostName, 22);
	    	s.setConfig("PreferredAuthentications", "publickey,keyboard-interactive,password");
		    s.setPassword(remoteHostpassword);
		    Properties config = new Properties();
		    config.put("StrictHostKeyChecking", "no");
		    s.setConfig(config);
		    s.connect();
		    flag = true;
		    s.disconnect();  		    	
	    }catch(Exception e){
	    	flag = false;
	    }
	    return flag;
	}

	 public boolean remoteCopy(String scriptFile) {
		 try
	     {
			 Channel c = getSession().openChannel("sftp");
			 ChannelSftp ce = (ChannelSftp) c;
			 ce.connect();
			 ce.put(scriptFile,"/tmp/"+scriptFile);
			 ce.disconnect();
			 return true;
	     }catch(Exception ex){
	    	 ex.printStackTrace();
	    	 return false;
	     }
	}
	
	public String removePassEntry(String str, String pass)
	{
		str = str.replaceAll(pass, "");
		return str;
	}
	
}
