/**
 * 
 */
package uk.o2.tcs.bmc;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Properties;

import uk.o2.tcs.bmc.model.ADDMDataModel;

import jxl.Sheet;
import jxl.Workbook;
import jxl.WorkbookSettings;
import jxl.read.biff.BiffException;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;

/**
 * @author Murugavel Ramachandran
 *
 */
public class ADDM_Wrapper {
	
	
	ArrayList<String> excel_input_arr = new ArrayList<String>();
	ArrayList<ADDMDataModel> addm_model_arr = new ArrayList<ADDMDataModel>();
	
    public static String batch = "";
    public static String mode = "";
    public static String file = "";

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	    // ADDM_Wrapper.java [-batch T4] -mode scan/update -file excelfilename 
	    for (int i=0; i < args.length; i++) {
	         switch (args[i].charAt(0)) {
	         case '-':
	             if (args[i].charAt(1) == '-') {
	                 int len = 0;
	                 String argstring = args[i].toString();
	                 len = argstring.length();
	                 if(argstring.substring(2, len).toString().equalsIgnoreCase("batch")){ batch = args[i+1]; } 
	                 else if(argstring.substring(2, len).toString().equalsIgnoreCase("mode")){ mode = args[i+1]; }
	                 else if(argstring.substring(2, len).toString().equalsIgnoreCase("file")){ file = args[i+1]; }
	                 i= i+1;
	             } else {
	            	 int len = 0;
	                 String argstring = args[i].toString();
	                 len = argstring.length();
	                 if(argstring.substring(1, len).toString().equalsIgnoreCase("batch")){ batch = args[i+1]; } 
	                 else if(argstring.substring(1, len).toString().equalsIgnoreCase("mode")){ mode = args[i+1]; }
	                 else if(argstring.substring(1, len).toString().equalsIgnoreCase("file")){ file = args[i+1]; }
	                 i= i+1;
	             }           
	             break;         
	         default:            
	         	break;         
	         }     
		}
		
	    if(mode.equalsIgnoreCase("") || file.equalsIgnoreCase("") || args.length < 4){
	    	System.out.println("\nADDM Rollout Wrapper Tool to connect Linux, Solaris and HP-UX");
	    	System.out.println("\n\tUsage: ADDM_Wrapper.java [-batch T4] -mode [scan/update] -file excelfilename");
	    } else {
			ADDM_Wrapper addm = new ADDM_Wrapper();
			// Collect host, password and other details
			addm.collectADDMHosts(file, batch);
			addm.processingADDMData();
	
	    }
	}
	
	public void processingADDMData() {
		
		Iterator<String> itr = excel_input_arr.iterator();
		int count = 1;
		
		while(itr.hasNext()){
			
			//Assign Variables
			String hostname = "";
			String username = "";
			String password = "";
			boolean userFlag = false;
			
			String line = itr.next();
			String data_arr[] = line.split("\\|");
			
			hostname = data_arr[0];
			
			System.out.println("\nProcessing ADDM Rollout task for hostname '"+hostname+"' - "+batch+"' - "+count+" of "+excel_input_arr.size());
			
			//Checking User and password authentication 
			String userPassList = data_arr[2];
			
			if(! userPassList.equalsIgnoreCase("")){
				String userPassArr[] = userPassList.split(",");
				for(int i=0; i<userPassArr.length; i++){
					String userPair[] = userPassArr[i].toString().split(":");
					userFlag = SSHRemoteManager.checkUserConnection(userPair[0], data_arr[0], userPair[1]);
					username = userPair[0];
					password = userPair[1];
					System.out.println(userFlag);
					if(userFlag){
						break;
					}
				}
			}else {
				System.out.println("\tUpdate password entry in excel for hostname="+hostname);
			}
			
			if(userFlag){
				scanOrUpdateHostForADDM(hostname, username, password, data_arr);
			}else {
				ADDMDataModel addmModelObj = new ADDMDataModel();
				addmModelObj.setHostname(hostname);
				addmModelObj.setUsername("Authentication issues for provided users to access server.");
				addmModelObj.setBatch(batch);
				addm_model_arr.add(addmModelObj);
				
			}

			count++;
		}
		
		//Excel Report Generation
		ADDMReportExcel are = new ADDMReportExcel();
		are.processADDMRolloutReport(addm_model_arr, batch);
		
	}
	
	public void scanOrUpdateHostForADDM(String hostname, String username, String password, String [] data_arr){
		
		ADDMDataModel addmModelObj = new ADDMDataModel();
		SSHRemoteManager sshObj = new SSHRemoteManager(hostname, username, password);
		
		String osName = clean(sshObj.executeShellCommandNew("uname -s"));
		String sudoPath = clean(sshObj.executeShellCommandNew("which sudo"));
		
		System.out.println("osName="+osName+"=");
		System.out.println("sudoPath="+sudoPath+"=");
		
		String scriptFile = "";
		String scriptLog = "";
		String nslookupPath = "";
		String ipcheck = "";
		String sudostatus = "";
		String sudoerspath = "";
		String securelogpath = "";

		if(osName.equalsIgnoreCase("HP-UX")){
			sudoPath = "/usr/local/bin/sudo";
			sudoerspath = "/etc/sudoers";
			nslookupPath = "nslookup";
			scriptFile = "addm_hp-ux.sh";
			securelogpath = "/var/adm/syslog/syslog.log";
		}else if(osName.equalsIgnoreCase("Linux")){
			sudoPath = "/usr/bin/sudo";
			scriptFile = "addm_linux.sh";
			nslookupPath = "nslookup";
			sudoerspath = "/etc/sudoers";
			securelogpath = "/var/log/secure";
		} else if(osName.equalsIgnoreCase("SunOS")){
			sudoPath = "/usr/local/bin/sudo";
			sudoerspath = "/usr/local/etc/sudoers";
			scriptFile = "addm_sunos.sh";
			nslookupPath = "/usr/sbin/nslookup";
			securelogpath = "";
		}
		
		//Based on OS, select script to execute in corresponding OS
		if(mode.equalsIgnoreCase("update")){
			// Script file copy to server
			boolean copyFlag = sshObj.remoteCopy(scriptFile);
			System.out.println("Script copied to server is ="+copyFlag+"=");
			
			
			// Script to be executed
			if(username.equalsIgnoreCase("root")){
				scriptLog = clean(sshObj.executeShellCommand("sh -x /tmp/"+scriptFile + " > /tmp/addm.log 2>&1"));
			} else {
				scriptLog = clean(sshObj.executeSudoCommand1(addmModelObj, sudoPath, password, "sh -x /tmp/"+scriptFile + " > /tmp/addm.log 2>&1"));
			}
			System.out.println("Script is submitted in background ...");
			
		} else {

			// Checking status of server based on tasks
			if(username.equalsIgnoreCase("root")){
				ipcheck = clean(sshObj.executeShellCommand(nslookupPath+" "+hostname));
			} else {
				if(osName.equalsIgnoreCase("SunOS")){
					//ipcheck = clean(sshObj.executeSudoCommand(sudoPath, password, nslookupPath+" "+hostname));
					ipcheck = clean(sshObj.executeShellCommandNew(nslookupPath+" "+hostname));
				} else {
					ipcheck = clean(sshObj.executeShellCommandNew(nslookupPath+" "+hostname));
				}
				
			}

			String uidcheck = clean(sshObj.executeShellCommandNew("grep bmcadmin /etc/passwd | awk -F: '{print $1,$3}' | awk '{print $2}'"));
			String gidcheck = clean(sshObj.executeShellCommandNew("grep 800 /etc/group | awk -F: '{print $3,$1}' | grep ^800 | awk '{print $2}'"));
			String homepath = clean(sshObj.executeShellCommandNew("grep bmcadmin /etc/passwd | awk -F: '{print $3,$6}' | awk '{print $2}'"));
			
			String homepath_permission = "";
			String sshpath_status = "";
			
			writeOutput("tab","Home Path : "+ homepath);
			
			if(!homepath.equalsIgnoreCase("") && homepath.contains("bmcadmin")){
				homepath_permission = clean(sshObj.executeSudoCommand1(addmModelObj, sudoPath, password, "ls -ld "+homepath));
				sshpath_status = "SSH Permission:\n\n" + clean(sshObj.executeSudoCommand1(addmModelObj, sudoPath, password, "ls -ld "+homepath+"/.ssh"));
				sshpath_status += "\n" + clean(sshObj.executeSudoCommand1(addmModelObj, sudoPath, password, "ls -l "+homepath+"/.ssh/authorized_keys"));
				sshpath_status += "\n\nSSH Key Count: " + clean(sshObj.executeSudoCommand1(addmModelObj, sudoPath, password, "cat "+homepath+"/.ssh/authorized_keys | wc -l"));				
			}
			
			writeOutput("tab","SSH Exception Status="+addmModelObj.getSshExceptionStatus()+"=");
			

			
			scriptLog = clean(sshObj.executeShellCommandNew("cat /tmp/addm.log"));
			
			//sudostatus += clean(sshObj.executeSudoCommand(sudoPath, password, "cat /etc/sudoers | grep -i bmc"));
			//sudostatus += clean(sshObj.executeSudoCommand(sudoPath, password, "cat /usr/local/etc/sudoers | grep -i bmc"));
			
			//sudostatus += sudoerspath+"\n\n"+clean(sshObj.executeSudoCommand(sudoPath, password, "cat "+sudoerspath+" | grep -i bmc"));
			
			String sudoFileExists = clean(sshObj.executeSudoCommand1(addmModelObj, sudoPath, password, "cat /usr/local/etc/sudoers | grep -i bmc"));
			if(! sudoFileExists.contains("No such file or directory")){
				sudostatus += "/usr/local/etc/sudoers"+"\n\n"+sudoFileExists;
			}else {
				sudostatus += "/etc/sudoers"+"\n\n"+clean(sshObj.executeSudoCommand1(addmModelObj, sudoPath, password, "cat /etc/sudoers | grep -i bmc"));
			}
			
			writeOutput("tab","SSH Exception Status="+addmModelObj.getSshExceptionStatus()+"=");
			
			writeOutput("tab","uidcheck="+uidcheck+"=");
			writeOutput("tab","gidcheck="+gidcheck+"=");
			writeOutput("tab","homepath_permission="+homepath_permission+"=");
			writeOutput("tab","sshpath_status="+sshpath_status+"=");
			writeOutput("tab","sudostatus="+sudostatus+"=");
			
			//Object Model
			addmModelObj.setHostname(hostname);
			addmModelObj.setUsername(username);
			addmModelObj.setOsname(osName);
			addmModelObj.setUidstatus(uidcheck);
			addmModelObj.setGidstatus(gidcheck);
			addmModelObj.setIpaddress(data_arr[1]);
			addmModelObj.setNslookup(ipcheck);
			addmModelObj.setScriptlog(scriptLog);
			addmModelObj.setBatch(batch);
			addmModelObj.setSudostatus(sudostatus);
			addmModelObj.setHomedir(homepath_permission);
			addmModelObj.setSshpermission(sshpath_status);
		}

		addm_model_arr.add(addmModelObj);
		sshObj.close();
		
		
	}
	
	public void writeOutput(String tab, String str){
		if(tab.equalsIgnoreCase("")) {
			System.out.println(str);
		} else {
			System.out.println("\t"+str);
		}
		
	}
	
	public void collectADDMHosts(String fileName, String batch){
		
		try {

			WorkbookSettings ws = new WorkbookSettings();
			ws.setEncoding("UTF-8");
			
			//Create a workbook object from the file at specified location. 
			//Change the path of the file as per the location on your computer. 
			Workbook wrk1 =  Workbook.getWorkbook(new File(fileName), ws);
			
			//Obtain the reference to the first sheet in the workbook
			Sheet sheet1 = wrk1.getSheet(0);
			
            int columns = sheet1.getColumns();
            int rows = sheet1.getRows();
            String data;

            for (int row = 0; row < rows; row++) {
            	String line = "";
                for (int col = 0; col < columns; col++) {
                	data = sheet1.getCell(col, row).getContents();
                    line = line + data + "|";
                }
                line = line + "END"; // Just for dummy
                
                String line_temp = line;
                line_temp = line_temp.replaceAll("\\|", "");
                line_temp = line_temp.replaceAll("END", "");
                
                //System.out.println("CHECK:"+line_temp+":OK");

                if( ! line.contains("Host Name") && 
               		! line.contains("IP Endpint") && 
               		! line_temp.equalsIgnoreCase("")
                ){
                	if( batch.equalsIgnoreCase("") ){
                		excel_input_arr.add(line);
                		//System.out.println("MURU"+line);
                		//breakLine();
                	} else {
                		if(line.contains("|"+batch+"|")) {
                			excel_input_arr.add(line);
                		}
                	}
                }
                

            }
            
		} catch (BiffException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}

	 public static void remoteCopy(String remoteHostUserName, String remoteHostName, String remoteHostpassword) throws JSchException, IOException, SftpException {
		    JSch js = new JSch();
		    Session s = js.getSession(remoteHostUserName, remoteHostName, 22);
		    s.setPassword(remoteHostpassword);
		    Properties config = new Properties();
		    config.put("StrictHostKeyChecking", "no");
		    s.setConfig(config);
		    s.connect();

		    Channel c = s.openChannel("sftp");
		    ChannelSftp ce = (ChannelSftp) c;
		    ce.connect();
		    ce.put("test.txt","/tmp/test.txt");
		    ce.disconnect();
		    s.disconnect();    
	}
	 
	 
	 void breakLine(){
		 try{
			 BufferedReader bufferRead = new BufferedReader(new InputStreamReader(System.in));
			 String s = bufferRead.readLine();
			 System.out.println(s);
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}		
	}
	 
	public String clean(String str){
		str = str.trim();
		return str;
	}
	
}
