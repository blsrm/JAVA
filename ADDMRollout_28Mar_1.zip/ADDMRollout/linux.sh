pwd
ls -ltra
