echo "Pass: abcd1234"
ssh -o StrictHostKeyChecking=no -t pandurs1@DMMLW-ESXVM-009 "/usr/bin/sudo sh -x /tmp/addm_linux.sh > /tmp/addm.log"
